extern "C" void _ZN7android16MediaBufferGroupC1Ev() { }
extern "C" void _ZNK7android11MediaSource11ReadOptions9getSeekToEPxPNS1_8SeekModeE() { }
extern "C" void _ZN7android16MediaBufferGroup14acquire_bufferEPPNS_11MediaBufferE() { }
extern "C" void _ZNK7android11MediaSource11ReadOptions9getLateByEv() { }
extern "C" void _ZNK7android11MediaSource11ReadOptions14getNonBlockingEv() { }
extern "C" void _ZN7android16MediaBufferGroup14acquire_bufferEPPNS_11MediaBufferEb() { }
