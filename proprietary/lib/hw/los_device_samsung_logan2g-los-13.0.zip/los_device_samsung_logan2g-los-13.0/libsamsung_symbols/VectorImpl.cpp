/*
 * Copyright (C) 2015 The CyanogenMod Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

extern "C" void _ZN7android10VectorImpl19reservedVectorImpl1Ev(void) { };
extern "C" void _ZN7android10VectorImpl19reservedVectorImpl2Ev(void) { };
extern "C" void _ZN7android10VectorImpl19reservedVectorImpl3Ev(void) { };
extern "C" void _ZN7android10VectorImpl19reservedVectorImpl4Ev(void) { };
extern "C" void _ZN7android10VectorImpl19reservedVectorImpl5Ev(void) { };
extern "C" void _ZN7android10VectorImpl19reservedVectorImpl6Ev(void) { };
extern "C" void _ZN7android10VectorImpl19reservedVectorImpl7Ev(void) { };
extern "C" void _ZN7android10VectorImpl19reservedVectorImpl8Ev(void) { };

extern "C" void _ZN7android16SortedVectorImpl25reservedSortedVectorImpl1Ev(void) { };
extern "C" void _ZN7android16SortedVectorImpl25reservedSortedVectorImpl2Ev(void) { };
extern "C" void _ZN7android16SortedVectorImpl25reservedSortedVectorImpl3Ev(void) { };
extern "C" void _ZN7android16SortedVectorImpl25reservedSortedVectorImpl4Ev(void) { };
extern "C" void _ZN7android16SortedVectorImpl25reservedSortedVectorImpl5Ev(void) { };
extern "C" void _ZN7android16SortedVectorImpl25reservedSortedVectorImpl6Ev(void) { };
extern "C" void _ZN7android16SortedVectorImpl25reservedSortedVectorImpl7Ev(void) { };
extern "C" void _ZN7android16SortedVectorImpl25reservedSortedVectorImpl8Ev(void) { };
