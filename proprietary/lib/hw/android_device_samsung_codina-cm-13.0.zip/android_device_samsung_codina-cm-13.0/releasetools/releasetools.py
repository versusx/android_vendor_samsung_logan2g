def FullOTA_InstallEnd(info):
#	info.script.AppendExtra('symlink("/system/lib/libjhead.so", "/system/lib/libhead.so");')
#	info.script.AppendExtra('run_program("/sbin/busybox", "mkdir", "/ramdisk");')
#	info.script.AppendExtra('run_program("/sbin/make_ext4fs", "/dev/block/mmcblk0p17");')
#	info.script.AppendExtra('ui_print("-> Extracting ramdisk folder...");')
#	info.script.AppendExtra('package_extract_dir("ramdisk", "/ramdisk");')
#	info.script.AppendExtra('run_program("/sbin/make_ext4fs", "/dev/block/mmcblk0p9");')
