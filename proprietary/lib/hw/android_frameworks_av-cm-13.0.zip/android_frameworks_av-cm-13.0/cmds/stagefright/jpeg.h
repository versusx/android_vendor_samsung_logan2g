#ifndef _STAGEFRIGHT_JPEG_H_
#define _STAGEFRIGHT_JPEG_H_

int writeJpegFile(const char *filename, uint8_t *frame, int width, int height);

#endif
